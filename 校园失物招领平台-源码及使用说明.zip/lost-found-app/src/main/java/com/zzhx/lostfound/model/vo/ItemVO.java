package com.zzhx.lostfound.model.vo;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 物品详情响应
 */
@Data
public class ItemVO {

    private Long id;

    private String type;

    private String title;

    private Long categoryId;

    private String categoryName;

    private String description;

    private List<String> images;

    private LocalDateTime eventTime;

    private String location;

    private String contactName;

    private String contactPhone;

    private String status;

    private Long userId;

    private String publisherName;

    private LocalDateTime createTime;
}
