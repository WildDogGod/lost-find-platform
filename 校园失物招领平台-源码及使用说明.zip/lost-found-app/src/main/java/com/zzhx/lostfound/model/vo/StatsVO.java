package com.zzhx.lostfound.model.vo;

import lombok.Data;

import java.util.List;

/**
 * 数据统计响应
 */
@Data
public class StatsVO {

    private Long totalUsers;

    private Long totalItems;

    private Long lostCount;

    private Long foundCount;

    private Long completedCount;

    private Double successRate;

    private List<CategoryCount> categoryDistribution;

    @Data
    public static class CategoryCount {

        private String categoryName;

        private Long count;
    }
}
