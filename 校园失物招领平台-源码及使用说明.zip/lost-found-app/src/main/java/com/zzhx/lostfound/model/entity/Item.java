package com.zzhx.lostfound.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 物品实体（失物 / 招领）
 */
@Data
@TableName("item")
public class Item {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** LOST 失物 / FOUND 招领 */
    private String type;

    private String title;

    private Long categoryId;

    private String description;

    /** 图片地址，多个逗号分隔 */
    private String images;

    private LocalDateTime eventTime;

    private String location;

    /** 隐藏特征（招领核验，不公开） */
    @JsonIgnore
    private String secretFeature;

    private String contactName;

    private String contactPhone;

    /** PENDING / ACTIVE / PROCESSING / COMPLETED / CLOSED */
    private String status;

    private String auditRemark;

    private Long userId;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}
