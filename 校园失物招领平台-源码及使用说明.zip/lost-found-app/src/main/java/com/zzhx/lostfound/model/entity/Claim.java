package com.zzhx.lostfound.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 认领记录实体
 */
@Data
@TableName("claim")
public class Claim {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long itemId;

    private Long applicantId;

    private String claimDesc;

    /** PENDING / APPROVED / REJECTED */
    private String status;

    private String reviewRemark;

    private Long reviewerId;

    private LocalDateTime createTime;

    private LocalDateTime reviewTime;
}
