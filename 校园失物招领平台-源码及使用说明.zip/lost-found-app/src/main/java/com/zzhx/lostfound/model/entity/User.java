package com.zzhx.lostfound.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.zzhx.lostfound.support.NullToEmptyStringSerializer;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 用户实体
 */
@Data
@TableName("user")
public class User {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String username;

    @JsonIgnore
    private String password;

    private String realName;

    private String studentNo;

    private String college;

    private String phone;

    private String email;

    /** 头像地址：数据库可空，但接口契约要求始终返回字符串 */
    @JsonSerialize(nullsUsing = NullToEmptyStringSerializer.class)
    private String avatar;

    private Integer verifyStatus;

    private String role;

    private Integer status;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}
