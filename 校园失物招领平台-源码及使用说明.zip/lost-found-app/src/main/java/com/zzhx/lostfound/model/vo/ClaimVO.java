package com.zzhx.lostfound.model.vo;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 认领记录响应
 */
@Data
public class ClaimVO {

    private Long id;

    private Long itemId;

    private Long applicantId;

    private String applicantName;

    private String claimDesc;

    private String status;

    private String reviewRemark;

    private LocalDateTime createTime;
}
