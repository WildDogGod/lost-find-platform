package com.zzhx.lostfound.model.vo;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.zzhx.lostfound.support.NullToEmptyStringSerializer;
import lombok.Data;

/**
 * 用户信息响应
 */
@Data
public class UserVO {

    private Long id;

    private String username;

    private String realName;

    private String studentNo;

    private String college;

    private String phone;

    private String email;

    /** 头像地址：数据库可空，但接口契约要求始终返回字符串 */
    @JsonSerialize(nullsUsing = NullToEmptyStringSerializer.class)
    private String avatar;

    private Integer verifyStatus;

    private String role;
}
