package com.zzhx.lostfound.model.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 发布物品请求
 */
@Data
public class ItemDTO {

    @NotBlank(message = "物品类型不能为空")
    private String type;

    @NotBlank(message = "物品标题不能为空")
    private String title;

    @NotNull(message = "物品分类不能为空")
    private Long categoryId;

    @NotBlank(message = "详细描述不能为空")
    private String description;

    private String images;

    @NotNull(message = "丢失/拾取时间不能为空")
    private LocalDateTime eventTime;

    @NotBlank(message = "地点不能为空")
    private String location;

    /** 隐藏特征（招领用于核验） */
    private String secretFeature;

    @NotBlank(message = "联系人不能为空")
    private String contactName;

    @NotBlank(message = "联系电话不能为空")
    private String contactPhone;
}
